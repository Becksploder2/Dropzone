# Drop Zone — Godot 4 playable source prototype

Open `project.godot` in **Godot 4.2+**, then press F6/F5 (Run Project). This is an original standalone 3D game-show prototype, **not** a finished release binary. No Chase/Chaser/Hunter creation areas exist.

## Implemented
- Procedurally generated 3D studio, bridge panels, overhead rings, host podium and placeholder contestant figures.
- Main menu, contestant names and human/AI toggles, host-name field, question editor, WAV/OGG music importer, settings, local JSON save.
- 3 contestants per round; each needs three correct selections to cross. Wrong selections drop the contestant. Correct selections are always safe.
- Host's catchphrase and manual suspense/reveal sequence; bridge panels turn green/red; contestant falls via tween.
- Round 1: $2,500/$5,000/$10,000 for 1/2/3 successful crossings. Round 2: $5,000/$10,000/$20,000. Further rounds double the base.
- Vault after each round: revive one eliminated contestant for half the accumulated bank.
- AI contestant play (manual AUTO PLAY button to advance AI decisions), configurable safe-answer probability.

## Prototype limitations
- **No Windows EXE/PCK was built or tested:** Godot executable/export templates are unavailable in this environment. Export via Godot Editor > Project > Export with Windows Desktop export templates installed. The source archive is provided for editing and testing.
- 3D characters are placeholders, not a modeled Karli-Rae with glasses/braces/reading glasses; no character appearance editor, animations, audience model, professional lighting cues, real audio sting, multiplayer network support, or packaged audio assets yet.
- The question creator supports 8 answers and a safe/unsafe bitmask. It does not yet expose a separate rich truth/lie dropdown or CSV importer.
- AI turns are advanced by button, not by automatic timer. Human players use onscreen answer buttons, not direct 3D raycast clicks.
- The camera is a fixed elevated studio view. The overhead rings are simple 3D torus meshes.
- Music import supports local WAV/OGG; MP3 conversion and asset embedding are not implemented.
- Bank is integer dollars; halves round down if odd.

## Development notes
The project uses only built-in Godot nodes and GDScript. Saved files are written to `user://drop_zone_save.json`. No external paid assets or copyrighted game-show music are included.
