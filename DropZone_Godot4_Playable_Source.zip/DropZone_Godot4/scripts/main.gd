extends Node3D

const SAVE_FILE := "user://drop_zone_save.json"
const QUESTIONS := [
 {"prompt":"Select the planets in our Solar System.","mode":"TRUTH","answers":["Mercury","Pluto","Venus","The Sun","Earth","Mars","The Moon","Jupiter"],"correct":[true,false,true,false,true,true,false,true]},
 {"prompt":"Select the animals that are mammals.","mode":"TRUTH","answers":["Dolphin","Shark","Bat","Penguin","Whale","Crocodile","Elephant","Frog"],"correct":[true,false,true,false,true,false,true,false]},
 {"prompt":"Select the statements that are FALSE.","mode":"LIE","answers":["Venus is the hottest planet","The Sun is a planet","Water freezes at 0°C at standard pressure","Mars has oceans today","A triangle has four sides","Sound travels in a vacuum","Earth has one moon","Jupiter is smaller than Earth"],"correct":[false,true,false,true,true,true,false,true]},
 {"prompt":"Select the countries located in Europe.","mode":"TRUTH","answers":["France","Brazil","Spain","Japan","Italy","Kenya","Norway","Canada"],"correct":[true,false,true,false,true,false,true,false]}
]

var bank := 0
var round_num := 1
var crossing := 0
var successful := 0
var selected_answer := -1
var game_state := "menu"
var contestants := ["Contestant 1","Contestant 2","Contestant 3"]
var alive := [true,true,true]
var ai := [false,true,true]
var question_bank: Array = []
var used_question_ids: Array = []
var current_question: Dictionary = {}
var chosen_indices: Array = []
var tiles: Array = []
var characters: Array = []
var stage: Node3D
var camera: Camera3D
var ui: Control
var info: Label
var heading: Label
var content: VBoxContainer
var overlay: ColorRect
var rng := RandomNumberGenerator.new()
var current_player := 0
var step_count := 0
var target_steps := 3
var music_path := ""
var music_player: AudioStreamPlayer
var host_name := "Karli-Rae Gomez"
var audio_volume := 0.75
var difficulty := 0.75
var awaiting_drop := false

func _ready() -> void:
 rng.randomize()
 load_data()
 create_world()
 create_ui()
 show_menu()

func load_data() -> void:
 question_bank = QUESTIONS.duplicate(true)
 if not FileAccess.file_exists(SAVE_FILE): return
 var parsed = JSON.parse_string(FileAccess.get_file_as_string(SAVE_FILE))
 if not parsed is Dictionary: return
 contestants = parsed.get("contestants",contestants)
 ai = parsed.get("ai",ai)
 question_bank = parsed.get("questions",question_bank)
 host_name = parsed.get("host",host_name)
 music_path = parsed.get("music","")
 audio_volume = parsed.get("volume",0.75)
 difficulty = parsed.get("difficulty",0.75)

func save_data() -> void:
 var data = {"contestants":contestants,"ai":ai,"questions":question_bank,"host":host_name,"music":music_path,"volume":audio_volume,"difficulty":difficulty}
 var file = FileAccess.open(SAVE_FILE,FileAccess.WRITE)
 if file: file.store_string(JSON.stringify(data,"  "))

func material(color: Color, metallic: float = 0.0) -> StandardMaterial3D:
 var m = StandardMaterial3D.new()
 m.albedo_color = color
 m.metallic = metallic
 m.roughness = 0.35
 return m

func box_mesh(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
 var mesh = MeshInstance3D.new()
 var b = BoxMesh.new()
 b.size = size
 mesh.mesh = b
 mesh.material_override = material(color,0.25)
 mesh.position = pos
 parent.add_child(mesh)
 return mesh

func create_world() -> void:
 stage = Node3D.new()
 add_child(stage)
 box_mesh(stage,Vector3(0,-0.8,0),Vector3(27,1.0,22),Color("11172d"))
 box_mesh(stage,Vector3(0,-0.25,-7),Vector3(23,0.3,3),Color("182f63"))
 box_mesh(stage,Vector3(0,2,-8.3),Vector3(24,4,0.3),Color("102e61"))
 box_mesh(stage,Vector3(0,2,-8.05),Vector3(17,2.5,0.1),Color("153b7c"))
 for x in [-4.5,4.5]:
  box_mesh(stage,Vector3(x,0,0),Vector3(1.0,0.4,13),Color("273e72"))
 for i in range(8):
  var tile = box_mesh(stage,Vector3(0,0,i*1.5-5.3),Vector3(7.8,0.24,1.25),Color("157db4"))
  tiles.append(tile)
 box_mesh(stage,Vector3(0,0,7),Vector3(9,0.4,2.5),Color("264c86"))
 box_mesh(stage,Vector3(0,0,-7),Vector3(9,0.4,2),Color("264c86"))
 # Decorative suspended concentric lighting rings above the entire studio.
 for radius in [6.0,8.0,10.0]:
  var ring = MeshInstance3D.new()
  var torus = TorusMesh.new()
  torus.inner_radius = radius-0.12
  torus.outer_radius = radius+0.12
  ring.mesh = torus
  ring.material_override = material(Color("57c5ee"))
  ring.position = Vector3(0,7.8+radius*0.15,0)
  stage.add_child(ring)
 # Studio host podium and simple procedural host placeholder.
 box_mesh(stage,Vector3(-9,0.65,-1),Vector3(2.5,1.5,1.4),Color("225d99"))
 box_mesh(stage,Vector3(-9,1.65,-1),Vector3(0.7,0.9,0.5),Color("bca28c"))
 box_mesh(stage,Vector3(-9,2.45,-1),Vector3(0.8,0.9,0.75),Color("e3c36b"))
 box_mesh(stage,Vector3(-9,2.4,-0.56),Vector3(0.85,0.13,0.12),Color("bf303d"))
 for i in range(3):
  var actor = Node3D.new()
  stage.add_child(actor)
  box_mesh(actor,Vector3(0,0.65,0),Vector3(0.65,1.2,0.5),Color("a34270") if i==0 else Color("4a78ba"))
  box_mesh(actor,Vector3(0,1.48,0),Vector3(0.55,0.55,0.55),Color("d7a887"))
  actor.position = Vector3(i*1.3-1.3,0,-6.7)
  characters.append(actor)
 camera = Camera3D.new()
 camera.position = Vector3(15,15,19)
 camera.rotation = Vector3(-0.58,0.65,0)
 add_child(camera)
 camera.look_at(Vector3(0,0,0),Vector3.UP)
 camera.current = true
 var light = DirectionalLight3D.new()
 light.rotation = Vector3(-0.7,0.4,0)
 light.light_energy = 1.2
 add_child(light)
 var world = WorldEnvironment.new()
 var env = Environment.new()
 env.background_mode = Environment.BG_COLOR
 env.background_color = Color("080d1e")
 env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
 env.ambient_light_color = Color("647fae")
 env.ambient_light_energy = 0.7
 world.environment = env
 add_child(world)
 music_player = AudioStreamPlayer.new()
 add_child(music_player)
 music_player.volume_db = linear_to_db(audio_volume)

func create_ui() -> void:
 ui = Control.new()
 ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 add_child(ui)
 var margin = MarginContainer.new()
 margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 margin.add_theme_constant_override("margin_left",24)
 margin.add_theme_constant_override("margin_right",24)
 margin.add_theme_constant_override("margin_top",16)
 margin.add_theme_constant_override("margin_bottom",18)
 ui.add_child(margin)
 var v = VBoxContainer.new()
 margin.add_child(v)
 heading = Label.new()
 heading.add_theme_font_size_override("font_size",38)
 heading.add_theme_color_override("font_color",Color("78e2ff"))
 v.add_child(heading)
 info = Label.new()
 info.add_theme_font_size_override("font_size",17)
 info.add_theme_color_override("font_color",Color("f8e4a1"))
 v.add_child(info)
 var space = Control.new()
 space.custom_minimum_size.y = 18
 v.add_child(space)
 content = VBoxContainer.new()
 content.custom_minimum_size.x = 480
 v.add_child(content)
 overlay = ColorRect.new()
 overlay.color = Color(0.025,0.045,0.11,0.88)
 overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 ui.add_child(overlay)
 ui.move_child(overlay,0)

func clear_controls() -> void:
 for child in content.get_children(): child.queue_free()

func button(label_text: String, action: Callable) -> void:
 var b = Button.new()
 b.text = label_text
 b.custom_minimum_size = Vector2(370,42)
 b.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
 b.pressed.connect(action)
 content.add_child(b)

func text_line(t: String) -> void:
 var l = Label.new()
 l.text = t
 l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 l.custom_minimum_size.x = 490
 content.add_child(l)

func show_menu() -> void:
 game_state = "menu"
 overlay.visible = true
 clear_controls()
 heading.text = "DROP ZONE"
 info.text = "Hosted by %s  |  Only wrong answers are drop zones" % host_name
 button("PLAY — Solo / AI / Local Team",func(): start_game())
 button("CREATE CONTESTANTS",show_contestants)
 button("CREATE HOST",show_host)
 button("QUESTION CREATOR",show_questions)
 button("MUSIC IMPORTER",show_music)
 button("SETTINGS",show_settings)
 button("HOW TO PLAY",show_help)
 button("QUIT",func(): get_tree().quit())

func show_contestants() -> void:
 clear_controls()
 heading.text = "CONTESTANT CREATOR"
 info.text = "Choose each contestant's name and whether AI controls them."
 for i in range(3):
  var idx = i
  var line = HBoxContainer.new()
  content.add_child(line)
  var field = LineEdit.new()
  field.text = contestants[i]
  field.custom_minimum_size.x = 260
  field.text_changed.connect(func(t): contestants[idx] = t; save_data())
  line.add_child(field)
  var toggle = CheckButton.new()
  toggle.text = "AI"
  toggle.button_pressed = ai[i]
  toggle.toggled.connect(func(v): ai[idx] = v; save_data())
  line.add_child(toggle)
 button("BACK",show_menu)

func show_host() -> void:
 clear_controls()
 heading.text = "HOST CREATOR"
 info.text = "Default host: blonde Karli-Rae, red glasses and chain, braces and readers."
 text_line("Prototype uses a placeholder 3D figure; custom character modeling is not implemented yet.")
 var field = LineEdit.new()
 field.text = host_name
 field.text_changed.connect(func(t): host_name=t; save_data())
 content.add_child(field)
 button("BACK",show_menu)

func show_questions() -> void:
 clear_controls()
 heading.text = "QUESTION CREATOR"
 info.text = "%d questions saved. Each question needs 8 choices and 8 safety flags." % question_bank.size()
 text_line("Use | to separate eight answers. Check each safe answer with 1; unsafe with 0.")
 var prompt_field = LineEdit.new()
 prompt_field.placeholder_text = "Prompt / category instruction"
 content.add_child(prompt_field)
 var answers_field = LineEdit.new()
 answers_field.placeholder_text = "Answer 1|Answer 2|...|Answer 8"
 content.add_child(answers_field)
 var flags_field = LineEdit.new()
 flags_field.placeholder_text = "1|0|1|0|1|0|1|0"
 content.add_child(flags_field)
 var feedback = Label.new()
 content.add_child(feedback)
 button("SAVE QUESTION",func():
  var a = answers_field.text.split("|")
  var f = flags_field.text.split("|")
  if prompt_field.text.strip_edges().is_empty() or a.size()!=8 or f.size()!=8:
   feedback.text="Enter a prompt, exactly 8 answers and 8 flags."
   return
  var checks = []
  for value in f:
   if value.strip_edges() != "0" and value.strip_edges() != "1":
    feedback.text="Flags must contain only 0 or 1."
    return
   checks.append(value.strip_edges()=="1")
  if checks.count(true)<3:
   feedback.text="At least 3 safe answers are needed."
   return
  question_bank.append({"prompt":prompt_field.text,"mode":"CUSTOM","answers":Array(a),"correct":checks})
  save_data()
  feedback.text="Saved! Total: %d" % question_bank.size()
 )
 button("BACK",show_menu)

func show_music() -> void:
 clear_controls()
 heading.text = "MUSIC IMPORTER"
 info.text = "Import a local WAV or OGG track (WAV PCM supported)."
 text_line("Current: %s" % (music_path if music_path!="" else "No track selected"))
 button("IMPORT MUSIC",func():
  var dialog = FileDialog.new()
  dialog.file_mode=FileDialog.FILE_MODE_OPEN_FILE
  dialog.access=FileDialog.ACCESS_FILESYSTEM
  dialog.add_filter("*.wav,*.ogg","Audio files")
  dialog.file_selected.connect(func(path): music_path=path; save_data(); try_play_music(); show_music())
  dialog.close_requested.connect(func(): dialog.queue_free())
  add_child(dialog)
  dialog.popup_centered(Vector2i(820,520))
 )
 button("PLAY IMPORTED MUSIC",try_play_music)
 button("STOP MUSIC",func(): music_player.stop())
 button("BACK",show_menu)

func try_play_music() -> void:
 if music_path.is_empty() or not FileAccess.file_exists(music_path): return
 var stream: AudioStream
 if music_path.to_lower().ends_with(".ogg"):
  stream = AudioStreamOggVorbis.load_from_file(music_path)
 elif music_path.to_lower().ends_with(".wav"):
  stream = AudioStreamWAV.load_from_file(music_path)
 if stream:
  music_player.stream=stream
  music_player.play()

func show_settings() -> void:
 clear_controls()
 heading.text = "SETTINGS"
 info.text = "Saved automatically to your Godot user-data directory."
 text_line("Music volume")
 var volume = HSlider.new()
 volume.min_value=0
 volume.max_value=1
 volume.step=0.05
 volume.value=audio_volume
 volume.custom_minimum_size.x=360
 volume.value_changed.connect(func(v): audio_volume=v; music_player.volume_db=linear_to_db(max(v,0.001)); save_data())
 content.add_child(volume)
 text_line("AI safe-answer probability")
 var skill = HSlider.new()
 skill.min_value=0.2
 skill.max_value=1
 skill.step=0.05
 skill.value=difficulty
 skill.custom_minimum_size.x=360
 skill.value_changed.connect(func(v): difficulty=v; save_data())
 content.add_child(skill)
 button("BACK",show_menu)

func show_help() -> void:
 clear_controls()
 heading.text = "HOW TO PLAY"
 info.text = "Find the truth or find the lie — read the current instruction."
 text_line("Each contestant must choose 3 safe panels to cross. A wrong choice drops them. The studio audience knows the drop zones, but cannot help.")
 text_line("Round 1: 1/2/3 successful crossings pay $2,500/$5,000/$10,000. Round 2 doubles these amounts.")
 text_line("After a round, revive one eliminated teammate by sacrificing half your accumulated bank. The bank persists between rounds.")
 text_line("AI contestants select automatically; human contestants click an answer panel. A question contains 8 choices and at least 3 safe answers.")
 button("BACK",show_menu)

func start_game() -> void:
 bank=0
 round_num=1
 alive=[true,true,true]
 used_question_ids=[]
 start_round()

func start_round() -> void:
 game_state="crossing"
 crossing=0
 successful=0
 for i in range(3):
  characters[i].visible=alive[i]
 begin_next_contestant()

func begin_next_contestant() -> void:
 if crossing>=3:
  end_round()
  return
 current_player=crossing
 if not alive[current_player]:
  crossing+=1
  begin_next_contestant()
  return
 step_count=0
 chosen_indices=[]
 load_question()

func load_question() -> void:
 var available=[]
 for i in range(question_bank.size()):
  if not used_question_ids.has(i) and question_bank[i].get("correct",[]).count(true)>=3: available.append(i)
 if available.is_empty():
  used_question_ids=[]
  for i in range(question_bank.size()):
   if question_bank[i].get("correct",[]).count(true)>=3: available.append(i)
 if available.is_empty(): show_menu(); return
 var id=available.pick_random()
 used_question_ids.append(id)
 current_question=question_bank[id]
 for i in range(8): tiles[i].material_override=material(Color("157db4"))
 render_bridge()

func render_bridge() -> void:
 overlay.visible = true
 clear_controls()
 heading.text = "ROUND %d  |  CROSSING %d/3" % [round_num,crossing+1]
 info.text = "%s  •  Step %d/%d  •  Bank $%d" % [contestants[current_player],step_count+1,target_steps,bank]
 text_line("%s — %s" % [current_question.get("mode","TRUTH"),current_question.get("prompt","")])
 for i in range(8):
  if chosen_indices.has(i): continue
  var idx=i
  button(str(current_question["answers"][i]),func(): select_answer(idx))
 if ai[current_player]:
  text_line("AI contestant: choose AUTO PLAY to continue.")
  button("AUTO PLAY AI TURN",ai_turn)
 button("BACK TO MAIN MENU",show_menu)

func ai_turn() -> void:
 if game_state!="crossing" or not ai[current_player]: return
 var safe=[]
 var unsafe=[]
 for i in range(8):
  if chosen_indices.has(i): continue
  if current_question["correct"][i]: safe.append(i)
  else: unsafe.append(i)
 var choose_safe=rng.randf()<difficulty or unsafe.is_empty()
 var pool=safe if choose_safe else unsafe
 if pool.is_empty(): pool=unsafe if choose_safe else safe
 if not pool.is_empty(): select_answer(pool.pick_random())

func select_answer(idx: int) -> void:
 if game_state!="crossing" or awaiting_drop: return
 selected_answer=idx
 awaiting_drop=true
 clear_controls()
 heading.text = "IS THAT A DROP ZONE?"
 info.text = "%s has stepped on: %s" % [contestants[current_player],current_question["answers"][idx]]
 text_line("Karli-Rae: 'Is... that... a DROP ZONE?'")
 button("REVEAL PANEL",reveal_panel)

func reveal_panel() -> void:
 if not awaiting_drop: return
 awaiting_drop=false
 var safe=bool(current_question["correct"][selected_answer])
 chosen_indices.append(selected_answer)
 tiles[selected_answer].material_override=material(Color("1ed884") if safe else Color("ed3149"))
 if safe:
  step_count+=1
  characters[current_player].position=Vector3(0,0,-6.7+step_count*3.3)
  if step_count>=target_steps:
   successful+=1
   crossing+=1
   show_reveal("SAFE! %s crossed successfully." % contestants[current_player],func(): begin_next_contestant())
  else:
   show_reveal("SAFE! Keep moving.",func(): render_bridge())
 else:
  alive[current_player]=false
  crossing+=1
  var tween=create_tween()
  tween.tween_property(characters[current_player],"position:y",-7.0,0.75)
  show_reveal("DROP ZONE! %s has fallen!" % contestants[current_player],func(): begin_next_contestant())

func show_reveal(message: String, next: Callable) -> void:
 clear_controls()
 heading.text=message
 info.text="Bank: $%d  |  Successful crossings: %d" % [bank,successful]
 button("CONTINUE",next)

func round_prize() -> int:
 if successful==0: return 0
 return 2500 * int(pow(2,round_num-1)) * int(pow(2,successful-1))

func end_round() -> void:
 game_state="vault"
 var award=round_prize()
 bank+=award
 clear_controls()
 heading.text="ROUND %d COMPLETE" % round_num
 info.text="%d crossed  •  Round prize: $%d  •  Team bank: $%d" % [successful,award,bank]
 text_line("THE VAULT — Bring back one eliminated teammate for HALF the team bank.")
 var can_revive=bank>0 and alive.has(false)
 if can_revive:
  for i in range(3):
   if alive[i]: continue
   var idx=i
   button("REVIVE %s — COST $%d" % [contestants[i],int(bank/2)],func():
    bank=int(bank/2)
    alive[idx]=true
    continue_after_vault()
   )
 button("KEEP THE MONEY — NEXT ROUND",continue_after_vault)
 button("FINISH AND BANK $%d" % bank,show_results)

func continue_after_vault() -> void:
 if not alive.has(true):
  show_results()
  return
 round_num+=1
 for actor in characters: actor.position.y=0
 start_round()

func show_results() -> void:
 game_state="results"
 clear_controls()
 heading.text="DROP ZONE — GAME OVER"
 info.text="Team total: $%d after %d rounds" % [bank,round_num]
 text_line("Thanks for playing! Hosted by %s." % host_name)
 button("PLAY AGAIN",start_game)
 button("MAIN MENU",show_menu)
